/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.EmployeeFacadeLocal;
import za.ac.tut.entities.Employee;

/**
 *
 * @author ALICIA TAU
 */
public class AddEmployeeServlet extends HttpServlet {
    @EJB
    private EmployeeFacadeLocal efl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long empID = Long.parseLong(request.getParameter("empID"));
        String cellNo = request.getParameter("cellNo");
        String nextKinCellNo = request.getParameter("nextKinCellNo");
        
        Employee employee = createEmployee(empID,cellNo,nextKinCellNo);
        efl.create(employee);
        
        RequestDispatcher disp = request.getRequestDispatcher("add_employee_outcome.jsp");
        disp.forward(request, response);
    }

    private Employee createEmployee(Long empID, String cellNo, String nextKinCellNo) {
        Employee emp = new Employee();
        List<String> list = new ArrayList<>();
        list.add(cellNo);
        list.add(nextKinCellNo);
        emp.setContactNos(list);
        emp.setId(empID);
        emp.setCreationDate(new Date());
        return emp;
    }

}
